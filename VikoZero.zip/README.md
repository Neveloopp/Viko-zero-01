# VikoZero — Transformer entrenado desde cero en Termux

VikoZero es un modelo de lenguaje causal tipo GPT creado para entrenarse desde pesos aleatorios.

**No usa Qwen, Llama, Ollama ni ningún modelo preentrenado.**
`tinygrad` se usa únicamente como motor matemático/autograd para ejecutar tensores y calcular gradientes. Los pesos del modelo los crea VikoZero aleatoriamente y los aprende exclusivamente de tus datos.

## Qué incluye

- Transformer causal GPT byte-level.
- Tokenizer UTF-8 propio, sin vocabulario descargado.
- Entrenamiento desde cero.
- Checkpoints `.safetensors`.
- Chat interactivo.
- Historial persistente.
- Dataset inicial de conversaciones con el estilo de Viko aprendido por ejemplos.
- Tres tamaños de modelo.
- Conversor de TXT pregunta/respuesta.
- Importador de texto libre.
- Generador de dataset adicional.
- Scripts listos para Termux.

## Instalación en Termux

```bash
pkg update -y
pkg install -y python git clang make pkg-config libjpeg-turbo
cd VikoZero
chmod +x install.sh viko
./install.sh
```

## Entrenar

Modelo pequeño (~1.9M parámetros):

```bash
./viko train tiny
```

Modelo base (~4.9M parámetros):

```bash
./viko train base
```

Modelo pesado (~14.5M parámetros):

```bash
./viko train heavy
```

Puedes detener con `Ctrl+C`. Se guarda un checkpoint al salir si ya hubo pasos entrenados.

Para continuar:

```bash
./viko train base --resume
```

## Hablar con Viko

```bash
./viko chat base
```

Comandos dentro del chat:

- `/help`
- `/clear` borra historial de conversación
- `/temp 0.75` cambia temperatura
- `/topk 40`
- `/topp 0.90`
- `/exit`

No se introduce ningún "prompt de personalidad" oculto durante el chat. El estilo se aprende de los ejemplos de entrenamiento.

## Añadir tu TXT de pares pregunta/respuesta

Si tu archivo tiene:

```text
hola
hola, qué tal
cómo estás
muy bien, ¿y tú?
```

usa:

```bash
python tools/import_pairs_txt.py mi_archivo.txt data/mis_pares.jsonl
```

Después vuelve a entrenar indicando varios datasets:

```bash
python train.py --config configs/base.json --data data/viko_seed.jsonl data/mis_pares.jsonl --resume
```

## Añadir texto libre

```bash
python tools/import_text.py libro.txt data/texto.jsonl
```

El texto libre ayuda a aprender idioma, escritura y conocimiento contenido en ese corpus. Las conversaciones ayudan a aprender a responder.

## Regenerar/ampliar el dataset inicial

```bash
./viko build-data
```

## Ver información del modelo

```bash
./viko info base
```

## Tamaños incluidos

| Preset | Dimensión | Capas | Cabezas | Contexto | Parámetros aprox. |
|---|---:|---:|---:|---:|---:|
| tiny | 192 | 4 | 6 | 256 | ~1.9M |
| base | 256 | 6 | 8 | 256 | ~4.9M |
| heavy | 384 | 8 | 8 | 384 | ~14.5M |

Los parámetros exactos los imprime `./viko info`.

## Importante

Entrenar desde cero es radicalmente distinto de ajustar un modelo preentrenado. El dataset incluido sirve para arrancar y enseñar formato conversacional/estilo, pero **no puede darle el conocimiento general de un LLM comercial**. Para conseguir respuestas realmente amplias y coherentes desde cero necesitas millones o cientos de millones de tokens de buena calidad y muchísimo cómputo.

En un teléfono, `tiny` es el mejor punto de prueba. `base` ya es serio. `heavy` es experimental: puede consumir bastante RAM, calentarse y entrenar muy lentamente.

La ventaja es que aquí sí puedes decir literalmente: **todos los pesos aprendidos son tuyos y nacieron desde cero**.
