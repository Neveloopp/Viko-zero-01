# Datos

`viko_seed.jsonl` es el dataset inicial incluido.

Formatos admitidos:

## Par simple

```json
{"prompt":"hola","response":"Holaa. ¿Qué tal?"}
```

## Conversación de varias vueltas

```json
{"messages":[
  {"role":"user","content":"hola"},
  {"role":"assistant","content":"Holaa."},
  {"role":"user","content":"qué haces"},
  {"role":"assistant","content":"Aquí contigo."}
]}
```

## Texto libre

```json
{"text":"Un bloque de texto que el modelo aprenderá a continuar..."}
```

No hay un prompt de personalidad en el runtime. El carácter de Viko sale de los patrones presentes en las respuestas del dataset.
